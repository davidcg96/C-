#include <iostream>
#include <array>
#include <cstdlib>
using namespace std;
const int DIM=2;
typedef array <int,DIM> TFila;
typedef array <TFila,DIM>TMatriz;
void LeerMatriz(TMatriz &m)
{
  for(int i=0;i<DIM;i++)
  {
    for(int j=0;j<DIM;j++)
    {
      cin>>m[i][j];
    }
  }
}
void EscribirMatriz(TMatriz &m)
{
  cout<<"mostrar matri<: "<<endl;
  for(int i=0;i<DIM;i++)
  {
    cout<<i<<":";
    for(int j=0;j<DIM;j++)
    {
      cout<<m[i][j]<<",";
    }
     cout<<endl;
  }
}
bool Simetrica(TMatriz &m)
{
  int i,j;
  bool ok=true;
  i=j=0;
   while(i<DIM && ok)
   {
      while(j<DIM && ok)
      {
        if(m[i][j]!=m[j][i])
          ok=false;
        j++;
      }
      i++;
   }
   return ok;
}
int main()
{
  TMatriz m1;
  cout<<"introducir numeros de la matriz "<<endl;
  LeerMatriz(m1);
  EscribirMatriz(m1);
  cout<<Simetrica(m1)<<endl;
  return 0;
}
