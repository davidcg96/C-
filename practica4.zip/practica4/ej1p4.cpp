#include <iostream>
#include <cmath>
using namespace std;

typedef struct {

    float real, imag;

} TComplejo;


// Prototipos
void LeerComp (TComplejo &c);

void EscribirComp(TComplejo c);
void SumaComp(TComplejo c1, TComplejo c2, TComplejo &c3);
void MultComp(TComplejo c1, TComplejo c2, TComplejo &c3);
float Modulo(TComplejo &c);
TComplejo Conjugado(TComplejo &c);
int main() {

    TComplejo c1, c2, suma, mult,conj1,conj2;


    LeerComp(c1);
    LeerComp(c2);

    SumaComp( c1, c2, suma);
    MultComp( c1, c2, mult);

    conj1=Conjugado(c1);
    conj2=Conjugado(c2);
    cout<<endl<<endl;
    cout<<"La suma es: ";
    EscribirComp(suma);
    cout<<endl;

    cout<<"La multiplicacion es: ";
    EscribirComp(mult);
    cout<<endl;
    cout<<"el modulo del complejo c1 es: "<<Modulo(c1)<<endl;
    cout<<"el modulo del complejo c2 es: "<<Modulo(c2)<<endl;
    cout<<"el conjugado de c1 es: ";
    EscribirComp(conj1);
    cout<<endl;
    cout<<"el conjugado c2 es: ";
    EscribirComp(conj2);
    cout<<endl;
    return 0;

}

void SumaComp(TComplejo c1, TComplejo c2, TComplejo &c3){
    c3.real = c1.real+c2.real;
    c3.imag = c1.imag+c2.imag;
}

void MultComp(TComplejo c1, TComplejo c2, TComplejo &c3){
    c3.real = c1.real*c2.real-c1.imag*c2.imag;
    c3.imag = c1.real*c2.imag+c1.imag*c2.real;
}

float Modulo(TComplejo &c) {
    float aux=c.real*c.real+c.imag*c.imag;
    return sqrt(aux);
}
TComplejo Conjugado(TComplejo &c)
{
  TComplejo aux;
  aux.real=c.real;
  aux.imag=-c.imag;
  return aux;
}
void LeerComp (TComplejo &c){

    cout<<"Introduzca un n�mero complejo: "<<endl<<"\tParte real: ";
    cin>>c.real;
    cout<<"\tParte imag: ";
    cin>>c.imag;
    cout<<endl;
}

void EscribirComp(TComplejo c){

    cout<<"("<<c.real<<", "<<c.imag<<") ";

}
