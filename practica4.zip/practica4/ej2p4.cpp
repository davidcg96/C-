#include <iostream>
#include <cmath>
#include <array>
using namespace std;

const int DIM=2;
typedef struct {

    float real, imag;

} TComplejo;

typedef array <TComplejo,DIM> TVector;

void LeerComp (TComplejo &c){

    cout<<"Introduzca un n�mero complejo: "<<endl<<"\tParte real: ";
    cin>>c.real;
    cout<<"\tParte imag: ";
    cin>>c.imag;
    cout<<endl;
}

void EscribirComp(TComplejo c){

    cout<<"("<<c.real<<", "<<c.imag<<") ";

}
void LeerVector(TVector &v)
{
  for(int i=0;i<DIM;i++)
  {
    LeerComp(v[i]);
  }
}
void EscribirVector(TVector &v)
{
  for(int i=0;i<DIM;i++)
  {
    EscribirComp(v[i]);
  }
}
float Modulo(TComplejo &c) {
    float aux=c.real*c.real+c.imag*c.imag;
    return sqrt(aux);
}
TComplejo Conjugado(TComplejo &c)
{
  TComplejo aux;
  aux.real=c.real;
  aux.imag=-c.imag;
  return aux;
}
void MultComp(TComplejo c1, TComplejo c2, TComplejo &c3){
    c3.real = c1.real*c2.real-c1.imag*c2.imag;
    c3.imag = c1.real*c2.imag+c1.imag*c2.real;
}
void Suma(TVector &c1,TVector &c2,TVector &c3)
{
  for(int i=0;i<DIM;i++)
  {
    c3[i].real=c1[i].real+c2[i].real;
    c3[i].imag=c1[i].imag+c2[i].imag;
  }
}
void PEscalar(TVector &c1,TVector &c2,TVector &c3)
{
  TVector aux;
  for(int i=0;i<DIM;i++)
  {
    aux[i]=Conjugado(c2[i]);
    MultComp(c1[i],aux[i],c3[i]);
  }
}
bool Buscar(TVector &v,TComplejo &c)
{
  int i=0;
  while(i<DIM && v[i].real!=c.real && v[i].imag!=c.imag)
  {
    i++;
  }
  if(i==DIM)
    return false;
  else
    return true;
}
float MayorReal(TVector &c1)
{
  float aux=c1[0].real;
  for(int i=1;i<DIM;i++)
  {
    if(aux<c1[i].real)
      aux=c1[i].real;
  }
  return aux;
}
float MayorModulo(TVector &c1)
{
  float aux=Modulo(c1[0]);
  for(int i=1;i<DIM;i++)
  {
    if(aux<Modulo(c1[i]))
      aux=Modulo(c1[i]);
  }
  return aux;
}
void Ajustar(TVector &c1)
{
  float x=MayorModulo(c1);
  for(int i=0;i<DIM;i++)
  {
    c1[i].real=c1[i].real/x;
    c1[i].imag=c1[i].imag/x;
  }
}
int main() {

    TVector c1, c2, suma, mult;
    TComplejo b;
    cout<<"introducir vector 1"<<endl;
    LeerVector(c1);
    cout<<"introducir vector 2"<<endl;
    LeerVector(c2);
    cout<<"la suma es:"<<endl;
    Suma( c1, c2, suma);
    EscribirVector(suma);
    cout<<endl;
    cout<<"el producto escalar es:"<<endl;
    PEscalar(c1,c2,mult);
    EscribirVector(mult);
    cout<<endl;
    cout<<"1 elemento encontrado 0 no"<<endl;
    cout<<"complejo a buscar: "<<endl;
    LeerComp(b);
    cout<<Buscar(c1,b);
    cout<<endl;

    cout<<"la parte real mayor de c1 es: "<<MayorReal(c1)<<endl;

    Ajustar(c1);
    EscribirVector(c1);
    return 0;

}
