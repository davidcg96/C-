#include <iostream>
#include <cmath>
#include <array>
using namespace std;

const int DIM=4;

typedef array <int,DIM> TVector;

void LeerVector(TVector &v)
{
  for(int i=0;i<DIM;i++)
  {
    cin>>v[i];
  }
}
void EscribirVector(TVector & v)
{
  cout<<"(";
  for(int i=0;i<DIM;i++)
  {
    cout<<v[i]<<",";
  }
  cout<<")"<<endl;
}
bool Moda(TVector &v)
{
  int moda,cont,cont2,nmoda;
  cont=0;
  cont2=0;
  nmoda=0;
  for(int i=0;i<DIM;i++)
  {
    if(v[i]!=-1)
    {
      moda=v[i];
      for(int j=0;j<DIM;j++)
      {
        if(moda==v[j])
        {
          cont++;
          v[j]=-1;
        }
      }
      cout<<"contador: "<<cont<<endl;
      if(i==0)
      {
        cont2=cont;
      }
      else
      {
        if(cont==cont2 )
        {
          nmoda++;
        }
        else if(cont2<cont)
        {
          cont2=cont;
          nmoda=0;
        }
      }
      cont=0;
    }
  }
  if(nmoda==1)
    return false;
  else
    return true;
}
int main()
{
  TVector v1;
  cout<<"introducir numeros: "<<endl;
  LeerVector(v1);
  cout<<endl;
  EscribirVector(v1);
  cout<<"hay moda?: "<<Moda(v1);
  return 0;
}
