#include <iostream>
#include <cstdlib>
#include <cmath>
using namespace std;

int main()
{
  unsigned n1,n2,n,cont,indice;
  cout<<"introducir numero n1"<<endl;
  cin>>n1;

  cout<<"introducir numero n2"<<endl;
  cin>>n2;
  while(n2>9)
  {
    cout<<"introducir numero n2"<<endl;
    cin>>n2;
  }
  cont=n1;
  indice=1;
  n=0;
  while(cont%10!=0)
  {
    if(indice%2==0)
      n=n*10+cont%10;
    else
    {
      n=n*10+n2;
    }
    cont=cont/10;
    indice++;
  }
  cout<<"el resultado es: "<<n;
  return 0;
}
