#include <iostream>
#include <cstdlib>
using namespace std;

bool esprimo(int numero)
{
  int cont =1;
  for(int i=2;i<=numero/2;i++)
  {
    if(numero%i==0)
      cont++;
  }
  if(cont>1)
    return false;
  else
    return true;
}
int main()
{
  int n1;
  cout<<"introducir numero n1"<<endl;
  cin>>n1;

  int indice=1;
  while(indice<n1)
  {
    if(esprimo(indice))
      cout<<indice<<","<<endl;
    indice++;
  }

  return 0;
}
