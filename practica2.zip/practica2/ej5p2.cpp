#include <iostream>
#include <cstdlib>
#include <cmath>
using namespace std;

const int numero=28;

bool EsPerfecto(int num)
{
  int suma=0;
  for(int i=1;i<=num/2;i++)
  {
    if(num%i==0)
    {
      suma=suma+i;
    }
  }
  if(suma==num)
    return true;
  else
    return false;
}
int main()
{
  int indice=numero+1;
  while(!EsPerfecto(indice))
  {
    indice++;
  }
  cout<<"el primer numero perfecto mayor que 28 es: "<<indice<<endl;
  return 0;
}
