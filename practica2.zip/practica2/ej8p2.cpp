#include <iostream>
using namespace std ;
const char SIMBOLO = '*';
int main ()
{
  int n;
  cout << " Introduzca un n�mero : ";
  cin >> n;
  for (int j = 0; j < n; ++j)
  {
    for (int i = 0; i < n-j-1; ++i)
    {
      cout << " ";
    }
    for (int i = 0; i < 2*j+1; ++i)
    {
      if ((j==0)||(j==n-1)||(i==0)||(i==2*j))
      {
        cout << SIMBOLO ;
      }
      else
      {
        cout << " ";
      }
    }
    cout << endl ;
  }
}
