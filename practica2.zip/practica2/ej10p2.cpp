#include <iostream>
#include <cstdlib>
#include <cmath>
using namespace std;

int main()
{
  unsigned n;
  cout<<"introducir tama�o"<<endl;
  cin>>n;

  unsigned cont=1;
  for(unsigned i=0;i<n;i++)
  {
    for(unsigned j=0;j<i+1;j++)
    {
      if(cont>9)
      {
        cout<<cont%10;
      }
      else
      {
        cout<<cont;
      }
      cont=cont+2;
    }
    cout<<endl;
    cont=1;
  }
   for(unsigned i=0;i<n-1;i++)
  {
    for(unsigned j=0;j<n-i-1;j++)
    {
      if(cont>9)
      {
        cout<<cont%10;
      }
      else
      {
        cout<<cont;
      }
      cont=cont+2;
    }
    cout<<endl;
    cont=1;
  }

  return 0;
}
