#include <iostream>
#include <cstdlib>
#include <cmath>
using namespace std;

int main()
{
  int n1,n2,n,cont;
  cout<<"introducir numero n1"<<endl;
  cin>>n1;
  cout<<"introducir numero n2"<<endl;
  cin>>n2;
  n=n2-n1;
  cont=1;
  cout<<"intentos "<<cont<<", "<<n1<<", "<<n2<<endl;
  while(abs(n)>10)
  {
    cout<<"introducir numero n2"<<endl;
    cin>>n2;
    n=n2-n1;
    cont++;
    cout<<"intentos "<<cont<<", "<<n1<<", "<<n2<<endl;
  }
  return 0;
}
