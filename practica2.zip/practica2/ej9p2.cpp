#include <iostream>
#include <cstdlib>
#include <cmath>
using namespace std;

int main()
{
  unsigned n;
  cout<<"introducir tama�o"<<endl;
  cin>>n;

  for(unsigned i=0;i<n;i++)
  {
      for(unsigned j=0;j<n-i-1;j++)
      {
        cout<<" ";
      }
      for(unsigned j=n-i-1;j<n+i+1;j++)
      {
        if(i%2!=0 && j%2==0)
        {
          cout<<" ";
        }
        if(i%2!=0 && j%2!=0)
        {
          cout<<"*";
        }
        if(i%2==0 && j%2==0)
        {
          cout<<"*";
        }
        if(i%2==0 && j%2!=0)
        {
          cout<<" ";
        }
      }
      cout<<endl;
  }
 return 0;
}
