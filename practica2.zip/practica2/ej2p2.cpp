#include <iostream>
#include <cstdlib>
#include <cmath>
using namespace std;

int main()
{
  int x,coef,indice,resul;
  indice=0;
  cout<<"introducir base"<<endl;
  cin>>x;

  cout<<"introducir coef "<<indice<<endl;
  cin>>coef;

  if(coef!=0)
  {
    resul=coef;
    indice++;
  }
  else
    cout<<"error al itroducir coef"<<endl;

  while(coef!=0)
  {
    cout<<"introducir coef "<<indice<<endl;
    cin>>coef;
    resul=resul+coef*pow(x,indice);
    indice++;
  }
  cout<<"el resultado es: "<<resul<<endl;
  return 0;
}
