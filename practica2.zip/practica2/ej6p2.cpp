#include <iostream>
#include <cstdlib>
#include <cmath>
using namespace std;

int main()
{
  unsigned n;
  cout<<"introducir tama�o"<<endl;
  cin>>n;
  unsigned cont=1;
  if(n<10)
  {
    for(unsigned i=1;i<=n;i++)
    {
      for(unsigned j=1;j<=n-i;j++)
      {
        cout<<" ";
      }
      for(unsigned k=1;k<=i;k++)
      {
        cout<<cont;
        cont++;
      }
      cont=i;
      for(unsigned p=1;p<=i-1;p++)
      {
        cont--;
        cout<<cont;
      }
      cout<<endl;
      cont=1;
    }
    cont=1;
    for(unsigned i=1;i<=n-1;i++)
    {
      for(unsigned j=1;j<=i;j++)
      {
        cout<<" ";
      }
      for(unsigned k=1;k<=n-i;k++)
      {
        cout<<cont;
        cont++;
      }
      cont=n-i;
      for(unsigned p=1;p<=n-i-1;p++)
      {
        cont--;
        cout<<cont;
      }
      cout<<endl;
      cont=1;
    }
  }
  return 0;
}
