#include <iostream>
#include <cstdlib>
#include <cmath>
using namespace std;

int main()
{
  unsigned n;
  cout<<"introducir tama�o"<<endl;
  cin>>n;
  char c;
  cout<<"introducir caracter"<<endl;
  cin>>c;

  for(unsigned i=0;i<n;i++)
  {
      if(i==0 || i==n-1)
      {
        for(unsigned j=0;j<n;j++)
        {
          cout<<c;
        }
      }
      else
      {
        cout<<c;
      }
      cout<<endl;
  }
 return 0;
}
