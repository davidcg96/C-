#include <iostream>
#include <cstdlib>
#include <array>
#include <cmath>
using namespace std;

const int DIM=6;

typedef array <int, DIM> Vec;
struct TVector
{
  Vec numeros;
  int tam;
};
void inicializar(TVector & v)
{
  v.tam=0;
}
TVector Suma(const TVector &uno,const TVector &dos,bool &ok)
{
  TVector suma;
  int i=0;
  inicializar(suma);
  if(uno.tam==dos.tam)
  {
    suma.tam=uno.tam;
    while(i<uno.tam)
    {
      suma.numeros[i]=uno.numeros[i]+dos.numeros[i];
      i++;
    }
    ok=true;
  }
  else
    ok=false;
  return suma;
}

bool Buscar(const TVector &v,int num)
{
  int i=0;
  while(i<v.tam && v.numeros[i]!=num)
  {
    i++;
  }
  if(i<v.tam)
    return true;
  else
    return false;
}
int Mayor(const TVector &v)
{
  int mayor=v.numeros[0];
  for(int i=1;i<v.tam;i++)
  {
    if(v.numeros[i]>mayor)
    {
      mayor=v.numeros[i];
    }
  }
  return mayor;
}
void Invertir(TVector &v)
{
  int aux;
  for(int i=0;i<v.tam/2;i++)
  {
    aux=v.numeros[v.tam-i-1];
    v.numeros[v.tam-i-1]=v.numeros[i];
    v.numeros[i]=aux;
  }
}
void Rotar(TVector &v,bool ok,int pos)
{
  int aux=0;
  int otro;
  if(ok)
  {
    for(int j=0;j<pos;j++)
    {
      for(int i=0;i<v.tam;i++)
      {
        if(i==0)
        {
          aux=v.numeros[i+1];
          v.numeros[(i+1)%v.tam]=v.numeros[i];
        }
        else
        {
          otro=v.numeros[i+1];
          v.numeros[(i+1)%v.tam]=aux;
          aux=otro;
        }
      }
    }
  }
  else
  {
    for(int j=0;j<v.tam-pos;j++)
    {
      for(int i=0;i<v.tam;i++)
      {
        if(i==0)
        {
          aux=v.numeros[i+1];
          v.numeros[(i+1)%v.tam]=v.numeros[i];
        }
        else
        {
          otro=v.numeros[i+1];
          v.numeros[(i+1)%v.tam]=aux;
          aux=otro;
        }
      }
    }
  }
}
void EscribirVector(const TVector &v)
{
  cout<<"el vector es: "<<endl;
  for(int i=0;i<v.tam;i++)
  {
    cout<<v.numeros[i]<<",";
  }
  cout<<endl;
}
void LeerVector(TVector &v)
{
  int i=0;
  cout<<"introducir vector"<<endl;
  int num=1;
  while(num!=0 && v.tam<DIM)
  {
    cin>>num;
    if(num!=0)
    {
      v.numeros[i]=num;
      v.tam++;
      i++;
    }
  }
  cout<<endl;
}
unsigned Menu () {
    int opcion;
    cout << endl;
    cout << "1. - introducir dos listas de vectores" << endl;
    cout << "2. - suma" << endl;
    cout << "3. - buscar" << endl;
    cout << "4. - rotar" << endl;
    cout << "5. - invertir" << endl;
    cout << "6. - mayor" << endl;
    cout << "0. - Salir" << endl;
    do {
        cout << "Introduzca Opcion: ";
        cin >> opcion;
    } while ( ! ((opcion >= 0) && (opcion <= 6)) );
    return opcion;
}
int main()
{
  TVector a,b,aux;
  bool oka;
  inicializar(a);
  inicializar(b);
   unsigned opcion;


    do {

        opcion = Menu();
        switch (opcion) {
        case 1:   LeerVector(a);
                  LeerVector(b);
            break;
        case 2:    // Inscribir deportista
                  aux=Suma(a,b,oka);
                  cout<<"la suma de los 2 vectores es: "<<endl;
                  EscribirVector(aux);
            break;

        case 3:
                  int elem;
                  cout<<"introducir elemento a buscar: "<<endl;
                  cin>>elem;
                  cout<<"el elemento (1 esta) o (0 no) en a: "<<Buscar(a,elem)<<endl;
                  cout<<"el elemento (1 esta) o (0 no) en b: "<<Buscar(b,elem)<<endl;
            break;

        case 4:
                  int po;
                  cout<<"introducir posiciones a mover"<<endl;
                  cin>>po;
                  Rotar(a,true,po);
                  cout<<"rotar a  pos a la derecha: "<<endl;
                  EscribirVector(a);
                  Rotar(b,false,po);
                  cout<<"rotar b  pos a la izquierda: "<<endl;
                  EscribirVector(b);

            break;

        case 5:
                  Invertir(a);
                  cout<<"invertir en a: "<<endl;
                  EscribirVector(a);
                  Invertir(b);
                  cout<<"invertir en b: "<<endl;
                  EscribirVector(b);
            break;
        case 6:
                  cout<<"el mayor elemento en a: "<<Mayor(a)<<endl;
                  cout<<"el mayor elemento en b: "<<Mayor(b)<<endl;
            break;
        }
    } while (opcion != 0 );


  return 0;
}
