#include <iostream>
#include <array>
#include <cstdlib>
using namespace std;
const int DIM=20;
typedef array <int,DIM> TFila;
typedef array <TFila,DIM>TCol;
struct TMatriz
{
  TCol matriz;
  int tfila;
  int tcolu;
};
void LeerMatriz(TMatriz &m)
{
  int i,j,fil,col;
  i=j=0;
  cout<<"introducir tama�o de la fila: "<<endl;
  cin>> fil;
  cout<<"introducir tama�o de la columna: "<<endl;
  cin>> col;
  if(fil>DIM)
    m.tfila=DIM;
  else
    m.tfila=fil;
  if(col>DIM)
    m.tcolu=DIM;
  else
    m.tcolu=col;
  cout<<"fila"<<m.tfila<<" columna"<<m.tcolu<<endl;
  cout<<"introducir matriz"<<endl;
  while(i<m.tfila)
  {
    while(j<m.tcolu)
    {
      cin>>m.matriz[i][j];
      j++;
    }
    j=0;
    i++;
  }
}
void EscribirMatriz(TMatriz &m)
{
  cout<<"mostrar matri<: "<<endl;
  for(int i=0;i<m.tfila;i++)
  {
    cout<<i<<":";
    for(int j=0;j<m.tcolu;j++)
    {
      cout<<m.matriz[i][j]<<",";
    }
     cout<<endl;
  }
}
bool Simetrica(TMatriz &m)
{
  int i,j;
  bool ok=true;
  i=j=0;
  if(m.tfila==m.tcolu && m.tfila<DIM)
  {
    while(i<m.tfila && ok)
    {
        while(j<m.tcolu && ok)
        {
          if(m.matriz[i][j]!=m.matriz[j][i])
            ok=false;
          j++;
        }
        i++;
    }
  }
   return ok;
}
int main()
{
  TMatriz m1;

  cout<<"introducir numeros de la matriz "<<endl;
  LeerMatriz(m1);
  EscribirMatriz(m1);
  cout<<"1 es simetrica y 0 no :"<<Simetrica(m1)<<endl;
  return 0;
}
