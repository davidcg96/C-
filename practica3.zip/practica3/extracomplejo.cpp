#include <iostream>
#include <cstdlib>
#include <array>
#include <cmath>

using namespace std;
const int DIM=3;
typedef array <int, DIM> TVector;

struct TComplejo
{
  int real;
  int imag;
};
struct TComplejos
{
  TVector real;
  TVector imag;
};
void inicializar(TVector & v)
{
  for(int i=0;i<DIM;i++)
  {
    v[i]=0;
  }
}
int Suma(const TVector &uno)
{
  int suma=uno[0];
  for(int i=1;i<DIM;i++)
  {
    suma=suma+uno[i];
  }
  return suma;
}
TComplejo SumaComplejo(const TComplejos &uno)
{
  TComplejo sum;
  sum.real=Suma(uno.real);
  sum.imag=Suma(uno.imag);
  return sum;
}
int Resta(const TVector &uno)
{
  int res=uno[0];
  for(int i=1;i<DIM;i++)
  {
    res=res-uno[i];
  }
  return res;
}
TComplejo RestaComplejo(const TComplejos &uno)
{
  TComplejo resta;
  resta.real=Resta(uno.real);
  resta.imag=Resta(uno.imag);
  return resta;
}
void EscribirComplejo(const TComplejos &v)
{
  cout<<"el vector es: "<<endl;
  for(int i=0;i<DIM;i++)
  {
    cout<<v.real[i]<<",";
    cout<<v.imag[i]<<"j ,";

  }
  cout<<endl;
}
void LeerComplejo(TComplejos &v)
{
  cout<<"introducir numeros complejos"<<endl;
  int num,num2;
  for(int i=0;i<DIM;i++)
  {
    cout<<"introducir parte real: ";
    cin>>num;
    v.real[i]=num;
    cout<<endl;
    cout<<"introducir parte imag: ";
    cin>>num2;
    v.imag[i]=num2;
    cout<<endl;
  }
}
void MostrarComplejo(const TComplejo &v)
{
  cout<<"parte real :"<< v.real<<", ";
  cout<<"parte IMAG :"<< v.imag<<", "<<endl;
}
int main()
{
  TComplejos n1;
  TComplejo aux;

  inicializar(n1.real);
  inicializar(n1.imag);

  LeerComplejo(n1);
  EscribirComplejo(n1);
  cout<<"la suma de los numeros complejos de n1: "<<endl;
  aux=SumaComplejo(n1);
  MostrarComplejo(aux);
  cout<<"la resta de los numeros complejos de n1: "<<endl;
  aux=RestaComplejo(n1);
  MostrarComplejo(aux);
  return 0;
}
