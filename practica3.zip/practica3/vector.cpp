#include <iostream>
#include <cstdlib>
#include <array>
#include <cmath>
using namespace std;

const int DIM=6;

typedef array <int, DIM> TVector;

void inicializar(TVector & v)
{
  for(int i=0;i<DIM;i++)
  {
    v[i]=0;
  }
}
TVector suma(const TVector &uno,const TVector &dos)
{
  TVector suma;
  inicializar(suma);
  for(int i=0;i<DIM;i++)
  {
    suma[i]=uno[i]+dos[i];
  }
  return suma;
}
TVector resta(const TVector &uno,const TVector &dos)
{
  TVector resta;
  inicializar(resta);
  for(int i=0;i<DIM;i++)
  {
    resta[i]=uno[i]-dos[i];
  }
  return resta;
}
int ProductoEscalar(const TVector &uno,const TVector &dos)
{
  int resul=0;
  for(int i=0;i<DIM;i++)
  {
    resul=resul+uno[i]*dos[i];
  }
  return resul;
}
bool Buscar(const TVector &v,int num)
{
  int i=0;
  while(i<DIM && v[i]!=num)
  {
    i++;
  }
  if(i<DIM)
    return true;
  else
    return false;
}
int Mayor(const TVector &v)
{
  int mayor=v[0];
  for(int i=1;i<DIM;i++)
  {
    if(v[i]>mayor)
    {
      mayor=v[i];
    }
  }
  return mayor;
}
void Invertir(TVector &v)
{
  int aux;
  for(int i=0;i<DIM/2;i++)
  {
    aux=v[DIM-i-1];
    v[DIM-i-1]=v[i];
    v[i]=aux;
  }
}
void Rotar(TVector &v,bool ok,int pos)
{
  int aux=0;
  int otro;
  if(ok)
  {
    for(int j=0;j<pos;j++)
    {
      for(int i=0;i<DIM;i++)
      {
        if(i==0)
        {
          aux=v[i+1];
          v[(i+1)%DIM]=v[i];
        }
        else
        {
          otro=v[i+1];
          v[(i+1)%DIM]=aux;
          aux=otro;
        }
      }
    }
  }
  else
  {
    for(int j=0;j<DIM-pos;j++)
    {
      for(int i=0;i<DIM;i++)
      {
        if(i==0)
        {
          aux=v[i+1];
          v[(i+1)%DIM]=v[i];
        }
        else
        {
          otro=v[i+1];
          v[(i+1)%DIM]=aux;
          aux=otro;
        }
      }
    }
  }
}
void EscribirVector(const TVector &v)
{
  cout<<"el vector es: "<<endl;
  for(int i=0;i<DIM;i++)
  {
    cout<<v[i]<<",";
  }
  cout<<endl;
}
void LeerVector(TVector &v)
{
  cout<<"introducir vector"<<endl;
  int num;
  for(int i=0;i<DIM;i++)
  {
    cin>>num;
    v[i]=num;
  }
  cout<<endl;
}
int main()
{
  TVector a,b,aux;
  inicializar(a);
  inicializar(b);
  LeerVector(a);
  LeerVector(b);
  aux=suma(a,b);
  cout<<"la suma de los 2 vectores es: "<<endl;
  EscribirVector(aux);
  aux=resta(a,b);
  cout<<"la resta de los 2 vectores es: "<<endl;
  EscribirVector(aux);
  cout<<"producot escalar de los 2 vectores es: "<<ProductoEscalar(a,b)<<endl;
  int elem;
  cout<<"introducir elemento a buscar: "<<endl;
  cin>>elem;
  cout<<"el elemento (1 esta) o (0 no) en a: "<<Buscar(a,elem)<<endl;
  cout<<"el elemento (1 esta) o (0 no) en b: "<<Buscar(b,elem)<<endl;
  cout<<"el mayor elemento en a: "<<Mayor(a)<<endl;
  cout<<"el mayor elemento en b: "<<Mayor(b)<<endl;
  Invertir(a);
  cout<<"invertir en a: "<<endl;
  EscribirVector(a);
  Invertir(b);
  cout<<"invertir en b: "<<endl;
  EscribirVector(b);
  int po;
  cout<<"introducir posiciones a mover"<<endl;
  cin>>po;
  Rotar(a,true,po);
  cout<<"rotar a  pos a la derecha: "<<endl;
  EscribirVector(a);
  Rotar(b,false,po);
  cout<<"rotar b  pos a la izquierda: "<<endl;
  EscribirVector(b);
  return 0;
}
