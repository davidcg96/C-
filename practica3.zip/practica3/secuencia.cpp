#include <iostream>
#include <cstdlib>
#include <array>
#include <cmath>
using namespace std;

float leer()
{
  int pa;
  cout<<"introducir lado, si despues de introducirlo es negativo volver a introducir"<<endl;
  do
  {
    cout<<"introducir lado : ";
    cin>>pa;
  }while(pa<0);
  return pa;
}
void Escribir(float pa, float pb, float pc)
{
  cout<<"("<<pa<<","<<pb<<","<<pc<<")"<<endl;
}
float Semiper(float pa,float pb, float pc)
{
  return (pa+pb+pc)/2;
}
float Area(float pa,float pb, float pc)
{
  float s=Semiper(pa,pb,pc);
  float arg=s*(s-pa)*(s-pb)*(s-pc);
  return sqrt(arg);
}
int main()
{
  float a,b,c,d,f,g,ar1,ar2;
  a=leer();
  b=leer();
  c=leer();
  cout<<" triangulo 1: "<<endl;
  Escribir(a,b,c);

  d=leer();
  f=leer();
  g=leer();
  cout<<" triangulo 2: "<<endl;
  Escribir(d,f,g);

  ar1=Area(a,b,c);
  ar2=Area(f,g,d);
  if(ar1>ar2)
    cout<<"el area mayor es del triangulo 1: "<<ar1<<endl;
  else
     cout<<"el area mayor es del triangulo 2: "<<ar2<<endl;
  return 0;
}
