#include <iostream>
#include <cstdlib>
#include <array>
#include <cmath>

using namespace std;
const int DIM=50;
typedef array <int, DIM> TVector;

struct TComplejo
{
  int real;
  int imag;
};
struct TComplejos
{
  TVector real;
  TVector imag;
  int tam;
};
void inicializar(TVector & v)
{
  for(int i=0;i<DIM;i++)
  {
    v[i]=0;
  }
}

TComplejos SumaComplejo(const TComplejos &uno,const TComplejos &dos)
{
  TComplejos sum;
  inicializar(sum.real);
  inicializar(sum.imag);
  for(int i=0;i<uno.tam;i++)
  {
    sum.real[i]=uno.real[i]+dos.real[i];
    sum.imag[i]=uno.imag[i]+dos.imag[i];
  }
  sum.tam=uno.tam;
  return sum;
}

TComplejos RestaComplejo(const TComplejos &uno,const TComplejos &dos)
{
  TComplejos resta;
  inicializar(resta.real);
  inicializar(resta.imag);
  for(int i=0;i<uno.tam;i++)
  {
    resta.real[i]=uno.real[i]-dos.real[i];
    resta.imag[i]=uno.imag[i]-dos.imag[i];
  }
  resta.tam=uno.tam;
  return resta;
}
void EscribirComplejo(const TComplejos &v)
{
  cout<<"el vector es: "<<endl;
  for(int i=0;i<v.tam;i++)
  {
    cout<<v.real[i]<<", ";
    cout<<v.imag[i]<<"j ,";
  }
  cout<<endl;
}
void LeerComplejo(TComplejos &v)
{
  cout<<"introducir numeros complejos"<<endl;
  int num,num2;
  int p;
  cout<<"introducir tama�o de complejos que desea"<<endl;
  cin>>p;
  int i=0;
  while(i<DIM && i!=p)
  {
    cout<<"introducir parte real: ";
    cin>>num;
    v.real[i]=num;
    cout<<endl;
    cout<<"introducir parte imag: ";
    cin>>num2;
    v.imag[i]=num2;
    cout<<endl;
    v.tam++;
    i++;
  }
}
void MostrarComplejo(const TComplejo &v)
{
  cout<<"parte real :"<< v.real<<", ";
  cout<<"parte IMAG :"<< v.imag<<", "<<endl;
}
int main()
{
  TComplejos n1,n2;
  TComplejos aux;
  inicializar(n1.real);
  inicializar(n1.imag);
  inicializar(n2.real);
  inicializar(n2.imag);
  n1.tam=0;
  n2.tam=0;

  LeerComplejo(n1);
  EscribirComplejo(n1);
  LeerComplejo(n2);
  EscribirComplejo(n2);
  if(n1.tam==n2.tam)
  {
    cout<<"la suma de los numeros complejos de n1 y n2: "<<endl;
    aux=SumaComplejo(n1,n2);
    EscribirComplejo(aux);
    cout<<"la resta de los numeros complejos de n1 y n2: "<<endl;
    aux=RestaComplejo(n1,n2);
    EscribirComplejo(aux);
  }
  return 0;
}
